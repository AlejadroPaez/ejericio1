<div class="container<?php echo (isset($full))?'-fluid':''; ?>">
  <div class="row">
    <div class="col-md-12">
      <div class="col-md-9 col-xs-7 col-sm-9 " style="padding-left:25px;">
        <h3>Ejercicio #1</h3>
      </div>
    </div>
  </div>
  <hr class="divider-title" style="margin-top: 10px;">
  <section class="cuerpo">
    <div class="row">
      <div class="col-md-12">
        <div style="height:472px" class="panel panel-default">

        <h3>Agregar nuevo producto</h3>
        <div>
          <form action="../controllers/controlador.php?accion=guardar" method="POST">
            <label for="">Producto</label><input type="text">
            <label for="">Precio</label><input type="text">
            <input type="submit" id="btnGuardar" value="Guardar">
          </form>
        </div>
        <h3>Contenido</h3>
        <table>
          <thead>
            <tr>
              <td>id</td>
              <td>Producto</td>
              <td>Precio</td>
              <td>tasa IVA</td>
              <td>IVA</td>
              <td>Precio + IVA</td>
            </tr>
          </thead>
          <tbody>
              <?php
                $total = 0;
                foreach($producto as $producto){
                  echo "<tr>";
                    $total = $producto['precio'] + $producto['impuesto'];
                    echo "<td>" . $producto['id'] . "</td>";
                    echo "<td>" . $producto['nombre'] . "</td>";
                    echo "<td>" .'$'. $producto['precio'] . "</td>";
                    echo "<td>" . $producto['tasa'] . "</td>";
                    echo "<td>" .'$'. $producto['impuesto'] . "</td>";
                    echo "<td>" .'$'. $total . "</td>";
                    echo "<td><a href='../controllers/controlador.php?accion=eliminar&id=".$producto['id']."'>ELIMINAR</a><td>";
                    echo "<td> <input type='button' value='Modificar'> </td>";
                  echo "</tr>";
                }
              ?>
          </tbody>
        </table>           
        </div>
      </div>
    </div>
  </section>
  </div>
</div>
</div>
</section>
</div>
</body>
<script type="text/javascript">

</script>
</html>
