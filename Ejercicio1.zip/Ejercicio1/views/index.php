<?php
    require('../controllers/controlador.php');
?>